const mqtt = require("mqtt");
const client = mqtt.connect("mqtt://localhost:1883");
const { processTelemetry } = require("./processTelemetry");

client.on("connect", () => {
  console.log("MQTT Connected");
  client.subscribe("telemetry/+");
});

client.on("message", (topic, msg) => {
  const data = JSON.parse(msg.toString());
  processTelemetry(data);
});

module.exports = client;
