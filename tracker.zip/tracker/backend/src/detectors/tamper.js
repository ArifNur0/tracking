const db = require("../db");
const ws = require("../ws");

let prev = {};

module.exports.check = async function (t) {
  const id = t.asset_id;

  if (!prev[id]) {
    prev[id] = t;
    return;
  }

  // Battery drop > 20% in 1 minute
  if (prev[id].battery_pct - t.battery_pct >= 20) {
    const ev = {
      asset_id: id,
      type: "battery_drop",
      ts_event: new Date().toISOString(),
      payload: {
        prev: prev[id].battery_pct,
        now: t.battery_pct,
        location: { lat: t.lat, lon: t.lon }
      }
    };

    await db.query(
      `INSERT INTO events(asset_id,type,ts_event,payload) VALUES ($1,$2,$3,$4)`,
      [ev.asset_id, ev.type, ev.ts_event, ev.payload]
    );

    ws.broadcast({ type: "event", data: ev });
  }

  if (t.sensors?.cover_open) {
    const ev = {
      asset_id: id,
      type: "cover_off",
      ts_event: new Date().toISOString(),
      payload: { location: { lat: t.lat, lon: t.lon } }
    };

    await db.query(
      `INSERT INTO events(asset_id,type,ts_event,payload) VALUES ($1,$2,$3,$4)`,
      [ev.asset_id, ev.type, ev.ts_event, ev.payload]
    );

    ws.broadcast({ type: "event", data: ev });
  }

  prev[id] = t;
};
