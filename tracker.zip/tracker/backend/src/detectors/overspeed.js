const db = require("../db");
const ws = require("../ws");

let state = {}; // {asset_id:{start_ts,max_speed}}

const SPEED_LIMIT = 80;
const DURATION = 5 * 1000;

module.exports.check = async function (t) {
  const id = t.asset_id;

  if (t.speed_kmh > SPEED_LIMIT) {
    if (!state[id]) {
      state[id] = {
        start: Date.now(),
        max: t.speed_kmh
      };
    }
    state[id].max = Math.max(state[id].max, t.speed_kmh);
  } else {
    if (state[id]) {
      const duration = Date.now() - state[id].start;
      if (duration >= DURATION) {
        const ev = {
          asset_id: id,
          type: "overspeed",
          ts_event: new Date().toISOString(),
          payload: {
            ts_start: state[id].start,
            ts_end: Date.now(),
            max_speed: state[id].max,
            threshold: SPEED_LIMIT,
            location: { lat: t.lat, lon: t.lon }
          }
        };

        await db.query(
          `INSERT INTO events(asset_id,type,ts_event,payload) VALUES ($1,$2,$3,$4)`,
          [ev.asset_id, ev.type, ev.ts_event, ev.payload]
        );

        ws.broadcast({ type: "event", data: ev });
      }
    }
    delete state[id];
  }
};
