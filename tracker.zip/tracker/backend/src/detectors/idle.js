const db = require("../db");
const ws = require("../ws");

let last = {}; // state

const IDLE_SPEED = 5;
const IDLE_DURATION = 10 * 60 * 1000;
const DIST_TOL = 20;

function distance(a, b) {
  return Math.sqrt(
    Math.pow(a.lat - b.lat, 2) + Math.pow(a.lon - b.lon, 2)
  ) * 111000;
}

module.exports.check = async function (t) {
  const id = t.asset_id;

  if (!last[id]) {
    last[id] = { start: null, ref: { lat: t.lat, lon: t.lon } };
  }

  const dist = distance(last[id].ref, t);

  if (t.speed_kmh < IDLE_SPEED && dist < DIST_TOL) {
    if (!last[id].start) {
      last[id].start = Date.now();
    }

    const d = Date.now() - last[id].start;
    if (d >= IDLE_DURATION) {
      const ev = {
        asset_id: id,
        type: "idle",
        ts_event: new Date().toISOString(),
        payload: {
          ts_start: last[id].start,
          ts_end: Date.now(),
          location: last[id].ref,
          duration_ms: d
        }
      };

      await db.query(
        `INSERT INTO events(asset_id,type,ts_event,payload) VALUES ($1,$2,$3,$4)`,
        [ev.asset_id, ev.type, ev.ts_event, ev.payload]
      );

      ws.broadcast({ type: "event", data: ev });

      last[id].start = null;
    }
  } else {
    last[id] = { start: null, ref: { lat: t.lat, lon: t.lon } };
  }
};
