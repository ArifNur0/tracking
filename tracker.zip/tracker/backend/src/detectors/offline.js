const db = require("../db");
const ws = require("../ws");

let lastSeen = {};

const TIMEOUT = 15 * 60 * 1000;

module.exports.update = function (t) {
  lastSeen[t.asset_id] = { ts: Date.now(), lat: t.lat, lon: t.lon };
};

setInterval(async () => {
  const now = Date.now();

  for (const id in lastSeen) {
    const delta = now - lastSeen[id].ts;

    if (delta > TIMEOUT) {
      const ev = {
        asset_id: id,
        type: "offline",
        ts_event: new Date().toISOString(),
        payload: {
          last_seen: lastSeen[id].ts,
          duration_ms: delta,
          last_location: { lat: lastSeen[id].lat, lon: lastSeen[id].lon }
        }
      };

      await db.query(
        `INSERT INTO events(asset_id,type,ts_event,payload) VALUES ($1,$2,$3,$4)`,
        [ev.asset_id, ev.type, ev.ts_event, ev.payload]
      );

      ws.broadcast({ type: "event", data: ev });

      delete lastSeen[id];
    }
  }
}, 5000);
