const express = require('express');
const router = express.Router();
const db = require('../db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const SECRET = process.env.JWT_SECRET || 's852f35eaabc04c72d686682e013ea454';

router.post('/register', async (req,res) => {
  const { username, password } = req.body;
  const hash = await bcrypt.hash(password, 10);
  try {
    await db.query('INSERT INTO users(username,password_hash) VALUES($1,$2)', [username, hash]);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'db' }); }
});

router.post('/login', async (req,res) => {
  const { username, password } = req.body;
  const r = await db.query('SELECT * FROM users WHERE username=$1', [username]);
  if (!r.rows.length) return res.status(401).json({ error: 'invalid' });
  const user = r.rows[0];
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'invalid' });
  const token = jwt.sign({ sub: user.id, username }, SECRET, { expiresIn: '8h' });
  res.json({ token });
});

module.exports = router;
