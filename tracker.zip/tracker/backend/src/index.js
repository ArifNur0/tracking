const express = require("express");
const app = express();

app.use(express.json());

app.use("/api/assets", require("./routes/assets"));
app.use("/api/auth", require("./routes/auth"));
app.use("/api/telemetry", require("./routes/telemetry"));

require("./mqtt");
require("./ws");

app.listen(3000, () => console.log("API ready on port 3000"));
