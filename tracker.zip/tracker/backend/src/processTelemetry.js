const db = require("./db");
const overspeed = require("./detectors/overspeed");
const idle = require("./detectors/idle");
const offline = require("./detectors/offline");
const tamper = require("./detectors/tamper");
const ws = require("./ws");

async function processTelemetry(t) {

  // Simpan data telemetry
  await db.query(`
    INSERT INTO telemetry(asset_id, ts, lat, lon, speed_kmh, heading, battery_pct, engine_on, sensors)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
  `, [
    t.asset_id, t.ts, t.lat, t.lon, t.speed_kmh,
    t.heading, t.battery_pct, t.engine_on, t.sensors
  ]);

  // Jalankan deteksi event
  overspeed.check(t);
  idle.check(t);
  offline.update(t);
  tamper.check(t);

  // Kirim realtime ke WebSocket
  ws.broadcast({ type: "telemetry_update", data: t });
}

module.exports = { processTelemetry };
