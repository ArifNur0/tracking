CREATE TABLE assets (
  id TEXT PRIMARY KEY,
  name TEXT,
  type TEXT,
  plate TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE telemetry (
  id BIGSERIAL PRIMARY KEY,
  asset_id TEXT REFERENCES assets(id),
  ts TIMESTAMPTZ,
  lat DOUBLE PRECISION,
  lon DOUBLE PRECISION,
  speed_kmh DOUBLE PRECISION,
  heading DOUBLE PRECISION,
  battery_pct INT,
  engine_on BOOLEAN,
  sensors JSONB
);

CREATE TABLE events (
  id BIGSERIAL PRIMARY KEY,
  asset_id TEXT REFERENCES assets(id),
  type TEXT,
  ts_event TIMESTAMPTZ,
  payload JSONB
);
