import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'src/app.dart';
import 'src/providers/auth_provider.dart';
import 'src/providers/asset_provider.dart';
import 'src/services/api_service.dart';

void main() {
  final api = ApiService('http://localhost:3000'); // ubah sesuai backend Anda
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => AuthProvider(api)),
      ChangeNotifierProvider(create: (_) => AssetProvider()),
    ],
    child: const MyApp(),
  ));
}
