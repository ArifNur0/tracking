import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../providers/asset_provider.dart';

class MapScreen extends StatefulWidget { const MapScreen({super.key}); @override _MapScreenState createState() => _MapScreenState(); }

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? mapController;

  @override
  Widget build(BuildContext context) {
    final assetProv = Provider.of<AssetProvider>(context);
    return GoogleMap(
      initialCameraPosition: const CameraPosition(target: LatLng(-7.776, 110.374), zoom: 12),
      markers: assetProv.markers.values.toSet(),
      onMapCreated: (c) => mapController = c,
    );
  }
}
