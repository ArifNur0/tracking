import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/asset_provider.dart';
import 'map_screen.dart';
import '../widgets/event_feed.dart';

class DashboardScreen extends StatefulWidget { const DashboardScreen({super.key}); @override State<DashboardScreen> createState() => _DashboardScreenState(); }

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  void initState() {
    super.initState();
    // Start WS after login
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final auth = Provider.of<AuthProvider>(context, listen:false);
      final assets = Provider.of<AssetProvider>(context, listen:false);
      assets.initWebsocket('ws://localhost:8080', auth.token); // ubah url sesuai server
    });
  }

  @override
  Widget build(BuildContext context) {
    final assets = Provider.of<AssetProvider>(context);
    final auth = Provider.of<AuthProvider>(context, listen:false);

    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard'), actions: [
        IconButton(onPressed: () async { await auth.logout(); assets.disposeWs(); }, icon: const Icon(Icons.logout))
      ]),
      body: Column(children: [
        Expanded(child: MapScreen()),
        SizedBox(height: 200, child: EventFeed())
      ]),
    );
  }
}
