import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AuthProvider extends ChangeNotifier {
  final ApiService api;
  final storage = const FlutterSecureStorage();
  String? token;
  bool get isLoggedIn => token != null;

  AuthProvider(this.api) {
    _loadToken();
  }

  Future<void> _loadToken() async {
    token = await storage.read(key: 'jwt');
    if (token != null) api.setToken(token!);
    notifyListeners();
  }

  Future<void> login(String u, String p) async {
    final res = await api.login(u,p);
    token = res['token'];
    api.setToken(token!);
    await storage.write(key: 'jwt', value: token);
    notifyListeners();
  }

  Future<void> logout() async {
    token = null;
    await storage.delete(key: 'jwt');
    notifyListeners();
  }
}
