import 'package:flutter/material.dart';
import '../models/telemetry.dart';
import '../models/asset.dart';
import '../services/api_service.dart';
import '../services/websocket_service.dart';
import 'dart:collection';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class AssetProvider extends ChangeNotifier {
  final ApiService? api;
  WebsocketService? ws;
  Map<String, Asset> assets = {};
  Map<String, Telemetry> lastTelemetry = {};
  List<Map<String,dynamic>> events = [];
  Map<String, Marker> markers = {};

  AssetProvider({this.api});

  void setApi(ApiService a) {}

  void initWebsocket(String wsUrl, String? token) {
    ws?.close();
    ws = WebsocketService(url: wsUrl, token: token);
    ws!.onMessage = (m) {
      if (m['type'] == 'telemetry_update') {
        final t = Telemetry.fromJson(m['data']);
        lastTelemetry[t.assetId] = t;
        _updateMarker(t);
        notifyListeners();
      } else if (m['type'] == 'event') {
        events.insert(0, m['data']);
        notifyListeners();
      }
    };
    ws!.connect();
  }

  void disposeWs() {
    ws?.close();
  }

  void _updateMarker(Telemetry t) {
    final id = t.assetId;
    final pos = LatLng(t.lat, t.lon);
    final marker = Marker(
      markerId: MarkerId(id),
      position: pos,
      infoWindow: InfoWindow(title: id, snippet: 'speed: ${t.speedKmh.toStringAsFixed(1)} km/h'),
      rotation: t.heading,
      anchor: const Offset(0.5, 0.5),
    );
    markers[id] = marker;
  }

  UnmodifiableListView<Map<String,dynamic>> get recentEvents => UnmodifiableListView(events);
}
