import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/asset_provider.dart';

class EventFeed extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<AssetProvider>(context);
    final events = prov.recentEvents;
    return ListView.builder(
      itemCount: events.length,
      itemBuilder: (c,i) {
        final e = events[i];
        final type = e['type'] ?? 'event';
        final asset = e['asset_id'] ?? '';
        final ts = e['ts_event'] ?? '';
        return ListTile(
          leading: const Icon(Icons.notification_important),
          title: Text('$type - $asset'),
          subtitle: Text(ts.toString()),
        );
      },
    );
  }
}
