class Telemetry {
  final String assetId;
  final DateTime ts;
  final double lat, lon;
  final double speedKmh;
  final double heading;
  final int batteryPct;
  final bool engineOn;
  final Map<String, dynamic>? sensors;

  Telemetry({
    required this.assetId, required this.ts, required this.lat, required this.lon,
    required this.speedKmh, required this.heading, required this.batteryPct, required this.engineOn, this.sensors
  });

  factory Telemetry.fromJson(Map<String, dynamic> j) => Telemetry(
    assetId: j['asset_id'],
    ts: DateTime.parse(j['ts']),
    lat: (j['lat'] as num).toDouble(),
    lon: (j['lon'] as num).toDouble(),
    speedKmh: (j['speed_kmh'] as num).toDouble(),
    heading: (j['heading'] as num).toDouble(),
    batteryPct: (j['battery_pct'] as num).toInt(),
    engineOn: j['engine_on'] ?? false,
    sensors: j['sensors'] != null ? Map<String,dynamic>.from(j['sensors']) : null
  );
}
