class Asset {
  final String id;
  final String name;
  final String type;
  Asset({required this.id, required this.name, required this.type});
  factory Asset.fromJson(Map<String, dynamic> j) => Asset(
    id: j['id'], name: j['name'] ?? '', type: j['type'] ?? ''
  );
}
