import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  final String baseUrl;
  String? _token;
  ApiService(this.baseUrl);

  void setToken(String token){ _token = token; }

  Future<Map<String,dynamic>> login(String username, String password) async {
    final res = await http.post(Uri.parse('$baseUrl/api/auth/login'),
      headers: {'Content-Type':'application/json'},
      body: jsonEncode({'username':username,'password':password}));
    if (res.statusCode == 200) return jsonDecode(res.body);
    throw Exception('Login failed: ${res.statusCode} ${res.body}');
  }

  Future<List<dynamic>> getAssets() async {
    final res = await http.get(Uri.parse('$baseUrl/api/assets'),
      headers: _authHeaders());
    _throwIfBad(res);
    return jsonDecode(res.body) as List<dynamic>;
  }

  Future<List<dynamic>> getTelemetry(String assetId, {String? from, String? to}) async {
    final uri = Uri.parse('$baseUrl/api/assets/$assetId/telemetry').replace(queryParameters: {
      if (from!=null) 'from': from,
      if (to!=null) 'to': to
    });
    final res = await http.get(uri, headers: _authHeaders());
    _throwIfBad(res);
    return jsonDecode(res.body) as List<dynamic>;
  }

  Map<String,String> _authHeaders() {
    return {
      'Content-Type': 'application/json',
      if (_token != null) 'Authorization': 'Bearer $_token'
    };
  }

  void _throwIfBad(http.Response res){
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw Exception('API error ${res.statusCode}: ${res.body}');
    }
  }
}
