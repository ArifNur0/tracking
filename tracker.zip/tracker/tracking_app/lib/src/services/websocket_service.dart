import 'package:web_socket_channel/io.dart';
import 'dart:convert';

typedef OnMessage = void Function(Map<String,dynamic> msg);

class WebsocketService {
  IOWebSocketChannel? _channel;
  final String url;
  final String? token;
  OnMessage? onMessage;

  WebsocketService({required this.url, this.token});

  void connect() {
    final uri = Uri.parse(url);
    final wsUrl = uri.replace(queryParameters: { if (token!=null) 'token': token }).toString();
    _channel = IOWebSocketChannel.connect(wsUrl);
    _channel!.stream.listen((d) {
      try {
        final m = jsonDecode(d as String) as Map<String,dynamic>;
        onMessage?.call(m);
      } catch (e) { print('WS parse err $e'); }
    }, onDone: () { print('WS done'); }, onError: (e) { print('WS err $e'); });
  }

  void close() => _channel?.sink.close();
}
